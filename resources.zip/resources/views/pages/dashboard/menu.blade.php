<x-app-layout>

    <!-- <body data-layout="horizontal" data-topbar="dark"> -->

    <!-- Begin page -->
@extends('layouts.header')

<!-- start page title -->
    <div class="row">
        <div class="col-12">
            @include('pages.partials.profile.edit.title')
        </div>
    </div>
    <!-- end page title -->
{{--    <form id="profile-add-form" autocomplete="off" class="needs-validation" novalidate enctype="multipart/form-data">--}}
{{--        @csrf--}}
{{--        <div class="row">--}}
{{--            <div class="col-md-4">--}}
{{--                 @include('pages.partials.menu.form')--}}
{{--            <!-- end card -->--}}
{{--            </div>--}}
{{--            <!-- end col -->--}}
{{--            <div class="col-lg-8">--}}
{{--            --}}{{-- @include('pages.partials.profile.add.project-settings') --}}
{{--                <div id="profile-list">--}}
{{--                    <img src="waveLoader.svg" alt="">--}}
{{--                </div>--}}
{{--            </div>--}}
{{--            <!-- end col -->--}}
{{--            <div class="col-lg-8">--}}
{{--            </div>--}}
{{--            <!-- Output message -->--}}
{{--            <div id="output" class="mt-3"></div>--}}
{{--        </div>--}}
{{--        <!-- end row -->--}}
{{--    </form>--}}

    <div class="row">
        <div class="col-md-3">
            <form id="create-menu">
                @csrf
                @include('pages.partials.menu.formCategory')
                <button type="submit" class="btn btn-primary w-md" id="btnSubmit">Create Category</button>
            </form>
        </div>
        <div class="col-md-3">
            <form id="create-menu-sub">
                @csrf
                @include('pages.partials.menu.formSubCategory')
                <button type="submit" class="btn btn-primary w-md" id="btnSubCategory">Create Sub Category</button>
            </form>
        </div>
        <div class="col-md-3">
            <div id="menu-list">
                <img src="waveLoader.svg" alt="">
            </div>
        </div>
        <div class="col-md-3">
            <div id="sub-category-list">
                <img src="waveLoader.svg" alt="">
            </div>
        </div>
    </div>




    <!-- Right Sidebar -->
@extends('layouts.settings')
<!-- /Right-bar -->

    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>
</x-app-layout>



