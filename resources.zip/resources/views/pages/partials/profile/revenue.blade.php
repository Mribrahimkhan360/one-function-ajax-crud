<div class="card">
    <div class="card-body">
        <h4 class="card-title mb-4">Revenue</h4>
        <div id="revenue-chart" class="apex-charts" dir="ltr"></div>
    </div>
</div>
