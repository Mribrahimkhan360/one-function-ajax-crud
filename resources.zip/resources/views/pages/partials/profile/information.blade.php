<div class="card">
    <div class="card-body">
        <h4 class="card-title mb-4">Personal Information</h4>

        <p class="text-muted mb-4">Hi I'm Cynthia Price,has been the industry's standard dummy text To an English person, it will seem like simplified English, as a skeptical Cambridge.</p>
        <div class="table-responsive">
            <table class="table table-nowrap mb-0">
                <tbody>
                <tr>
                    <th scope="row">Full Name :</th>
                    <td>Cynthia Price</td>
                </tr>
                <tr>
                    <th scope="row">Mobile :</th>
                    <td>(123) 123 1234</td>
                </tr>
                <tr>
                    <th scope="row">E-mail :</th>
                    <td>cynthiaskote@gmail.com</td>
                </tr>
                <tr>
                    <th scope="row">Location :</th>
                    <td>California, United States</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
