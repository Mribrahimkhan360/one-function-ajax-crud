<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body border-bottom">
                <h5 class="mb-3">Social Media</h5>
                <div class="hstack gap-2">
                    <a href="#!" class="btn btn-soft-primary"><i class="bx bxl-facebook align-middle me-1"></i> Facebook </a>
                    <a href="#!" class="btn btn-soft-info"><i class="bx bxl-twitter align-middle me-1"></i> Twitter</a>
                    <a href="#!" class="btn btn-soft-pink"><i class="bx bxl-instagram align-middle me-1"></i> Instagram</a>
                    <a href="#!" class="btn btn-soft-success"><i class="bx bxl-whatsapp align-middle me-1"></i> Whatsapp</a>
                </div>
            </div>
        </div>
    </div>
</div>
