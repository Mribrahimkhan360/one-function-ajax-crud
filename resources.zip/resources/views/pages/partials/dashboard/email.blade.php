<div class="card">
    <div class="card-body">
        <div class="d-sm-flex flex-wrap">
            <h4 class="card-title mb-4">Email Sent</h4>
            <div class="ms-auto">
                <ul class="nav nav-pills">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Week</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Month</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Year</a>
                    </li>
                </ul>
            </div>
        </div>

        <div id="stacked-column-chart" class="apex-charts" data-colors='["--bs-primary", "--bs-warning", "--bs-success"]' dir="ltr"></div>
    </div>
</div>
