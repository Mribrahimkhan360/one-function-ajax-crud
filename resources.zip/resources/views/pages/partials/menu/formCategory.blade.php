<div class="form-floating mb-3">
    <input type="text" class="form-control" name="name" id="floatingemailInput" placeholder="Enter Category">
    <label for="floatingemailInput">Create Category</label>
</div>


